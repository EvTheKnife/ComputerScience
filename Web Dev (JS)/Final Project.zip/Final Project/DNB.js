var canvas = document.getElementById('canvas').getContext("2d");

canvas.font = "20px Arial";
canvas.fillText("1",80,20);
canvas.fillText("2",180,20);
canvas.fillText("3",280,20);
canvas.fillText("4",380,20);
canvas.fillText("5",480,20);
canvas.fillText("6",580,20);
canvas.fillText("7",680,20);
canvas.fillText("8",780,20);
