function play() {
    document.getElementById("circusMusic").play()
}